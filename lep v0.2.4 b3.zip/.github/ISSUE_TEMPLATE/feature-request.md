---
name: Feature Request
about: Suggesting Changes / New Features
title: "[REQ] Untitled"
labels: ''
assignees: ''

---

**I have confirmed that**
- This feature is not included in the latest version.
- This can be accomplished with data pack recipes.

**Current Behavior**
```
[ ] => [ ]
```

**Proposed Behavior**
```
[ ] => [ ]
```

**Additional Information**
[If Applicable]
