---
name: Bug Report
about: Reporting Unexpected Behavior(s)
title: "[BUG] Untitled"
labels: ''
assignees: ''

---

**I have confirmed that**
- The behavior is unexpected according to the wiki.
- This issue is apparent in the latest version.
- This is not an issue with an external pack.

**Versions**
LEP: X.X.X
Minecraft: 1.X.X

**Unexpected Behavior**
```
[ ] => [ ]
```

**Expected Behavior**
```
[ ] => [ ]
```

**Additional Information**
[If Applicable]
